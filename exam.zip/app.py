from flask import Flask, render_template, jsonify, request
app = Flask(__name__)

from pymongo import MongoClient
client = MongoClient('mongodb+srv://sparta:jungle@cluster0.rdd6tdr.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = client.dbjungle

## HTML을 주는 부분
@app.route('/')
def home():
   return render_template('index.html')

@app.route('/tdl', methods=['GET'])
def read_TDLs():
    # 1. mongoDB에서 _id 값을 제외한 모든 데이터 조회해오기 (Read)
    result = list(db.TDLs.find({}, {'_id': 0}))
    # 2. TDLs라는 키 값으로 article 정보 보내주기
    return jsonify({'result': 'success', 'TDLs': result})

@app.route('/tdl', methods=['POST'])
def post_TDLs():
    # 1. 클라이언트로부터 데이터를 받기
    todo_receive = request.form['todo_give']  # 클라이언트로부터 todo을 받는 부분
    todo = {'TDL': todo_receive}
    # 2. mongoDB에 데이터 넣기
    db.TDLs.insert_one(todo)
    return jsonify({'result': 'success'})


@app.route('/api/TDLs/delete', methods=['POST'])
def delete_TDL():
    # 1. 클라이언트가 전달한 title_give를 title_receive 변수에 넣습니다.
    TDL_receive = request.form['TDL_give']
    
    # 2. TDLs 목록에서 delete_one으로 TDL이 TDL_receive와 일치하는 TDLs을 제거합니다.
    db.TDLs.delete_one({"TDLs" : TDL_receive})
    # 3. 성공하면 success 메시지를 반환합니다.
    return jsonify({"result" : "success", "msg" : "삭제 완료!"})

if __name__ == '__main__':  
   app.run('0.0.0.0',port=5000,debug=True)